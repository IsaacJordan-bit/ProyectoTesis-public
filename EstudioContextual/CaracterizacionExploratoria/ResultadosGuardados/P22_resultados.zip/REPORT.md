# P22 exploratory contextual-representation report

Status: computational analysis complete for 640 words. Contract: `2639d8e76465de84146d39074a41604cf15d126de25999bb86f7d65162c4fcd8`.

This study characterizes the frozen P20/P21 cohort. It does not rerun memory retrieval,
fit the thesis classifier, select K, or use T1, T2, or T3. All comparisons are conditional
on this corpus, representation extraction, and lexical inventory.

## What to inspect

1. `tables/geometry_summary.csv`: contextual dispersion, anisotropy reference,
   prototype variance accounting, and changes in nearest lexical neighbours.
2. `tables/heldout_summary.csv`: every fixed probe-k and training fraction. Read
   relative compression gains jointly with random-partition and Gaussian controls.
3. `tables/probe_coverage.csv`: non-evaluable cells and their denominators.
4. `tables/category_omissions.csv`: category dependence without refitting.
5. `tables/text_summary.csv`: lexical-context association, when source texts exist.
6. `tables/occurrence_reference_summary.csv`: all TRAIN occurrences as a codebook,
   compared with the TRAIN mean; codebook capacities differ and are reported.

## Interpretation limits

The A=0 and O=1 endpoints for retained within-word variance follow by construction.
Frozen P is fitted on the same occurrences; its retained fraction is descriptive.
Held-out probes therefore refit all centroids on TRAIN records only. These diagnostic
K-means centroids are not the historical P induction algorithm or new retrieval arms.
Their test queries retain their full occurrence vectors to choose a nearest centroid;
this is a quantization test, not a deployment test with only a word identifier.
Within-word source-group hold-outs differ from the main word-disjoint retrieval
partitions and do not constitute additional retrieval trials.

A multi-centroid gain alone cannot establish distinct senses. A continuous unimodal
cloud can also benefit from quantization. The Gaussian control uses the full empirical
TRAIN covariance in its train span, with no shrinkage or added residual variance;
its contrast is sensitive to that finite-sample reference and is not a test of a
universal unimodality null. Inspect the test variance outside the train span as well.

Bootstrap intervals resample words within each of the fixed categories after averaging
repeated splits. They do not treat occurrence pairs, null draws, or repeated splits as
independent observations. They are conditional word-resampling summaries, not evidence
of replication in a new corpus. 5441 source records
are shared by multiple cohort words; document independence is not established.

Text status counts: {"OK": 625, "NOT_EVALUABLE": 15}.
Text association uses masked-target TF-IDF and record/duplicate groups. It measures
lexical context association, not independent human sense annotation. No automatic
semantic interpretation or favourable conclusion is generated.

## Manuscript placement

Methods: cohort, authenticated identities, descriptive metrics, held-out protocol,
controls, weighting, missing-cell policy, resource/software record.
Results: select the most informative geometry and held-out figures; preserve null
or unfavourable findings and coverage. T1/T2 remain the main thesis outcomes.
Discussion: distinguish contextual variation, compression, linguistic interpretation,
and the separate controlled retrieval findings.
Appendix: all word-level results, grids, controls, omissions, and implementation details.
The approved abstract, Spanish summary, and symbols section need no automatic revision.
