"""Read-only representation diagnostics; no outcome-derived admissibility threshold."""
from pathlib import Path
import sys,hashlib,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
import e2_k40_reference as r
import numpy as np,pandas as pd
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_limits

import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root',type=Path,default=Path(__file__).resolve().parents[1]/'sources')
parser.add_argument('--catalog-dir',type=Path,default=None)
parser.add_argument('--output',type=Path,default=Path.cwd()/'recomputed_catalog_results')
args=parser.parse_args()
SRC=args.source_root.resolve()
UP=args.catalog_dir.resolve() if args.catalog_dir else SRC/'catalog'
OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=True)
protocol=r.read85(SRC/'protocol_frozen.json');pid=r.digest85(protocol)
receipt=r.read85(UP/'completed.json')
assert receipt['identity']==r.digest85(dict(parent=pid,max_K=100))
for name in ('subset.pkl','catalog_metadata.json'):assert r.sha85(UP/name)==receipt['outputs'][name]
E=pd.read_pickle(UP/'subset.pkl')
meta=r.read85(UP/'catalog_metadata.json')
assert E.shape==(808,300) and not E.index.has_duplicates and np.isfinite(E.to_numpy()).all()
assert meta['embedding_sha256']==protocol['embedding_sha256']
assert np.linalg.norm(E.to_numpy(float),axis=1).min()>0

reconstruction=[];queryrows=[];augrows=[];splitsets={};geos={};neighs={}
with threadpool_limits(limits=1):
 for K in (40,50):
    geo=SRC/f'K{K}/geometry'
    r._receipt(geo,r.digest85(dict(parent=pid,K=K,phase='geometry')))
    neighbors=r.read85(geo/'neighbors.json');neighs[K]=neighbors
    assert list(neighbors)==r.CLASSES85
    aug=sum(neighbors.values(),[]);emb=E.loc[aug].copy()
    expected=pd.read_parquet(geo/'expected.parquet')
    audits=r.read85(geo/'split_audit.json')
    geos[K]=dict(expected=expected,full=pd.read_parquet(geo/'full.parquet'),common=pd.read_parquet(geo/'common.parquet'))
    classmap=r.build_word_class_map(neighbors)
    Y=np.array([classmap[w] for w in aug]);V=emb.to_numpy(float)
    norms=np.linalg.norm(V,axis=1);U=V/norms[:,None]
    sims=U@U.T
    centroids=np.stack([V[Y==c].mean(axis=0) for c in range(8)])
    normalized_centroids=centroids/np.linalg.norm(centroids,axis=1)[:,None]
    centroid_scores=U@normalized_centroids.T
    categories=E.loc[r.CLASSES85].to_numpy(dtype=float,copy=True);categories/=np.linalg.norm(categories,axis=1)[:,None]
    scores_categories=U@categories.T
    for c,label in enumerate(r.CLASSES85):
        mask=Y==c;within=sims[np.ix_(mask,mask)];inside=within[~np.eye(mask.sum(),dtype=bool)]
        other=np.delete(centroid_scores[mask],c,axis=1).max(axis=1)
        augrows.append(dict(K=K,true_class=c,class_label=label,n_units=int(mask.sum()),
          norm_mean=norms[mask].mean(),norm_sd=norms[mask].std(),norm_min=norms[mask].min(),norm_max=norms[mask].max(),
          within_class_cosine_mean=inside.mean(),within_class_cosine_min=inside.min(),
          category_cosine_min=scores_categories[mask,c].min(),category_cosine_mean=scores_categories[mask,c].mean(),
          centroid_cosine_margin_mean=(centroid_scores[mask,c]-other).mean(),
          centroid_cosine_misassigned_rate=(centroid_scores[mask].argmax(axis=1)!=c).mean()))
    for seed in range(51):
        sp=r.prepare_classification_split(emb,neighbors,frequency_threshold=2,validation_split=.33,
            random_seed_split=seed,pairwise_different_class=True)
        a=next(x for x in audits if x['split_seed']==seed)
        trainhash=r.digest85(sp.train_words)
        X=sp.train_embeddings.to_numpy(dtype='<f8');Q=sp.validation_embeddings.to_numpy(dtype='<f8')
        vectorhash=hashlib.sha256(X.tobytes()).hexdigest()
        assert trainhash==a['train_words_sha'] and vectorhash==a['train_array_sha'],(K,seed)
        got=pd.DataFrame(dict(word=sp.validation_words,true_class=sp.true_classes,
            validation_similarity=sp.validation_similarities)).sort_values('word').reset_index(drop=True)
        want=expected.loc[expected.split_seed.eq(seed),got.columns].sort_values('word').reset_index(drop=True)
        pd.testing.assert_frame_equal(got,want,check_dtype=False,check_exact=False,rtol=0,atol=1e-12)
        assert set(got.true_class)==set(range(8))
        reconstruction.append(dict(K=K,split_seed=seed,train_words_hash=True,train_vectors_hash=True,
            query_words_classes_identical=True,max_similarity_delta=float(abs(got.validation_similarity-want.validation_similarity).max()),
            n_train=len(X),n_query=len(Q)))
        splitsets[K,seed]=dict(train=set(sp.train_words),query=set(sp.validation_words))
        labels=np.array([classmap[w] for w in sp.train_words]);truth=sp.true_classes
        raw=Q@X.T; cosine=1-cdist(Q,X,metric='cosine')
        same=truth[:,None]==labels[None,:]
        raw_own=np.where(same,raw,-np.inf);raw_other=np.where(~same,raw,-np.inf)
        cos_own=np.where(same,cosine,-np.inf);cos_other=np.where(~same,cosine,-np.inf)
        md=raw_own.max(axis=1)-raw_other.max(axis=1)
        mc=cos_own.max(axis=1)-cos_other.max(axis=1)
        frame=pd.DataFrame(dict(K=K,split_seed=seed,word=sp.validation_words,true_class=truth,
            raw_margin=md,cosine_margin=mc,raw_wrong=(labels[raw.argmax(axis=1)]!=truth),
            cosine_wrong=(labels[cosine.argmax(axis=1)]!=truth),
            raw_own_winner=np.array(sp.train_words)[raw_own.argmax(axis=1)],
            raw_rival_winner=np.array(sp.train_words)[raw_other.argmax(axis=1)],
            cosine_own_max=cos_own.max(axis=1),cosine_rival_max=cos_other.max(axis=1)))
        for beta in (.01,.1,.495):
            A=r.attention_weights((beta*raw).T,r.CORE3[0]).T
            frame['softmax_own_mass_'+str(beta)]=(A*same).sum(axis=1)
            frame['softmax_effective_fraction_'+str(beta)]=1/(len(X)*np.square(A).sum(axis=1))
        queryrows.append(frame)
    print('K',K,'51 partitions reconstructed',flush=True)

rec=pd.DataFrame(reconstruction);aug=pd.DataFrame(augrows);query=pd.concat(queryrows,ignore_index=True)
paired=query.query('K==40').merge(query.query('K==50'),on=['split_seed','word','true_class'],suffixes=('_K40','_K50'),validate='one_to_one')
metrics=['raw_margin','cosine_margin','raw_wrong','cosine_wrong',
         'cosine_own_max','cosine_rival_max','softmax_own_mass_0.01','softmax_own_mass_0.1',
         'softmax_own_mass_0.495','softmax_effective_fraction_0.01','softmax_effective_fraction_0.1',
         'softmax_effective_fraction_0.495']
# Equal word within class, then equal class: repeated splits are not independent samples.
pair_words=paired.groupby(['word','true_class'])[[m+s for m in metrics for s in ('_K40','_K50')]].mean().reset_index()
pair_classes=pair_words.groupby('true_class').mean(numeric_only=True).reset_index()
pair_classes['class_label']=pair_classes.true_class.map(dict(enumerate(r.CLASSES85)))
for m in metrics:pair_classes[m+'_delta']=pair_classes[m+'_K50']-pair_classes[m+'_K40']
pair_classes['n_words']=pair_classes.true_class.map(pair_words.groupby('true_class').size())
pair_classes['n_word_split_pairs']=pair_classes.true_class.map(paired.groupby('true_class').size())
globalrows=[]
for m in metrics:
 globalrows.append(dict(metric=m,K40=float(pair_classes[m+'_K40'].mean()),K50=float(pair_classes[m+'_K50'].mean()),
     delta_K50_minus_K40=float(pair_classes[m+'_delta'].mean()),aggregation='equal_word_within_class_then_equal_class'))
changes=[]
for seed in range(51):
 a,b=splitsets[40,seed],splitsets[50,seed]
 changes.append(dict(split_seed=seed,common_train=len(a['train']&b['train']),dropped_train=len(a['train']-b['train']),
     added_train=len(b['train']-a['train']),common_query=len(a['query']&b['query']),
     K40_query_to_K50_train=len(a['query']&b['train']),K40_train_to_K50_query=len(a['train']&b['query'])))
additions=[]
for c,label in enumerate(r.CLASSES85):
 assert neighs[50][label][:40]==neighs[40][label]
 for rank,w in enumerate(neighs[50][label][40:],41):
  additions.append(dict(true_class=c,class_label=label,rank=rank,word=w,norm=float(np.linalg.norm(E.loc[w].to_numpy(float)))))
tables=dict(reconstruction=rec,augmented_geometry=aug,query_diagnostics=query,paired_words=pair_words,
    paired_classes=pair_classes,paired_global=pd.DataFrame(globalrows),split_changes=pd.DataFrame(changes),added_words=pd.DataFrame(additions))
for name,d in tables.items():d.to_csv(OUT/(name+'.csv'),index=False)
result=dict(catalog_identity_matches=True,subset_and_metadata_hashes_match=True,n_catalog_words=len(E),dimension=300,
    subset_dtype=str(E.dtypes.iloc[0]),all102_train_hashes_match=True,all102_validation_geometries_match=True,
    max_similarity_delta=rec.max_similarity_delta.max(),n_paired_word_split_rows=len(paired),n_paired_words=len(pair_words),
    available_catalog_receipt_files=['subset.pkl','catalog_metadata.json'],
    catalog_receipt_files_not_attached=[n for n in receipt['outputs'] if not (UP/n).is_file()],
    scope='representation and retrieval diagnostics, not classifier FAR or a new K selection rule',
    versions=dict(numpy=np.__version__,pandas=pd.__version__,scipy=r.scipy.__version__,sklearn=r.sklearn.__version__))
r.write85(OUT/'summary.json',result)
print(json.dumps(r.safe85(result),indent=2));print(pd.DataFrame(globalrows).to_string(index=False))
print(pair_classes[['class_label','n_words','raw_margin_delta','cosine_margin_delta','raw_wrong_delta','cosine_wrong_delta','softmax_own_mass_0.495_delta']].to_string(index=False))
print(pd.DataFrame(changes).mean(numeric_only=True).to_string())
