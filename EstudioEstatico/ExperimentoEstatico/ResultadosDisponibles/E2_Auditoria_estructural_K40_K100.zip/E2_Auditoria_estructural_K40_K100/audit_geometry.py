"""Auditoría geométrica de archivos existentes. No lee errores ni ajusta modelos.

Uso: python audit_geometry.py --inputs CARPETA_EXTRAIDA --source MODULO_ESTATICO --out SALIDA
Requiere numpy, pandas, pyarrow, scipy, scikit-learn==1.8.0 y threadpoolctl.
La comprobación de matrices de diseño usa funciones extraídas por AST del módulo
original, sin importarlo ni ejecutar su código global.
"""
from pathlib import Path
import argparse, ast, hashlib, json, platform, time
import numpy as np
import pandas as pd
import scipy, sklearn
from scipy.linalg import helmert
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import SplineTransformer
from threadpoolctl import threadpool_limits

LABELS = ['apple','bicycle','bread','canoe','chair','jellyfish','screwdriver','skunk']
SOURCE_SHA = 'ef2bd4039b7ca1f4577b6a11f342df89d1665807d92666e0a3fb7803d5268680'

def require(ok, message):
    if not bool(ok):
        raise RuntimeError(message)

def readj(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()

def checked_path(root, name):
    p=(root/name).resolve()
    require(p.is_relative_to(root.resolve()) and p.is_file(), 'Archivo ausente/ruta inválida: '+str(p))
    return p

def coverage(common):
    return common.groupby(['true_class','similarity_bin']).size().unstack(fill_value=0).reindex(index=range(8),columns=range(5),fill_value=0)

def original_design(source):
    require(sha(source)==SOURCE_SHA, 'El módulo de referencia es distinto.')
    code=Path(source).read_text(encoding='utf-8'); tree=ast.parse(code)
    names={'weights85','design85'}
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    require(len(nodes)==2, 'Referencia numérica ambigua.')
    env=dict(np=np,pd=pd,helmert=helmert,SplineTransformer=SplineTransformer,req85=require)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),env)
    specs=[]
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FAMILIES85' for t in n.targets):
            specs.append(ast.literal_eval(n.value))
    require(len(specs)==1 and len(specs[0])==9, 'Registro de familias ambiguo.')
    return env['design85'],specs[0]

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--inputs',type=Path,required=True)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args(); root=args.inputs.resolve(); out=args.out.resolve(); out.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()
    require(sklearn.__version__=='1.8.0','Se requiere sklearn 1.8.0 para reconstruir exactamente los folds auditados.')
    m=readj(root/'manifest.json')
    for item in m['files']:
        p=checked_path(root,item['archive_name'])
        require(p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'Hash de exportación distinto: '+str(p))
    verified=[]; inventory=[]; groups={}
    for pp in sorted(root.rglob('protocol_frozen.json')):
        protocol=readj(pp); pid=digest(protocol)
        require(pp.parent.name.endswith(pid[:20]),'Identidad de protocolo no reproducida: '+str(pp))
        dataset='W2V' if 'W2V' in pp.parts else 'GloVe'
        require(protocol.get('condition','RAW')=='RAW','Condición distinta de RAW')
        for gp in sorted(pp.parent.glob('K*/geometry/gate.json')):
            folder=gp.parent; K=int(folder.parent.name[1:]); gate=readj(gp)
            if not 40<=K<=100:continue
            receipt=readj(folder/('completed.json' if dataset=='W2V' else 'geometry_identity.json'))
            for name,h in receipt['outputs'].items():
                p=checked_path(folder,name)
                require(sha(p)==h,'Checksum histórico distinto: '+str(p))
                verified.append(dict(dataset=dataset,K=K,root=pp.parent.name,file=str(p.relative_to(root)),sha256=h))
            if dataset=='W2V':
                require(receipt['identity']==digest(dict(parent=pid,K=K,phase='geometry')),'Identidad de geometría W2V distinta')
            names=('full.parquet','expected.parquet') if dataset=='W2V' else ('full_words.parquet','expected_splits.parquet')
            # Igualdad exacta de tablas fuente; el binning histórico puede diferir.
            key=(dataset,K,sha(folder/names[0]),sha(folder/names[1]),sha(folder/'neighbors.json'))
            native_bins=len(gate['edges'])-1
            record=dict(dataset=dataset,K=K,root=pp.parent.name,version=protocol['version'],
                native_bins=native_bins,historical_A=gate['A'],historical_min=gate['min_words_class_bin'],
                equivalence_id=digest(list(key)),protocol_sha=sha(pp),geometry_identity=receipt['identity'],
                folder=str(folder.relative_to(root)))
            inventory.append(record)
            groups.setdefault(key,[]).append((folder,protocol,gate,record))
    rows=[]; cells=[]; words=[]; classes=[]; splits=[]; cvrows=[]; designrows=[]
    design,families=original_design(args.source)
    for key,items in sorted(groups.items()):
        dataset,K=key[:2]
        # Preferencia sólo de formato, nunca por resultado. Las entradas de cada
        # grupo ya tienen hashes idénticos para FULL, splits y vecinos.
        folder,protocol,gate,record=sorted(items,key=lambda t:(t[3]['native_bins']!=5,str(t[0])))[0]
        ident=record['equivalence_id']; base=dict(dataset=dataset,K=K,equivalence_id=ident)
        full=pd.read_parquet(folder/('full.parquet' if dataset=='W2V' else 'full_words.parquet'))
        expected=pd.read_parquet(folder/('expected.parquet' if dataset=='W2V' else 'expected_splits.parquet'))
        native_common=pd.read_parquet(folder/('common.parquet' if dataset=='W2V' else 'common_Z.parquet'))
        neighbors=readj(folder/'neighbors.json')
        require(list(neighbors)==LABELS,'Orden de clases distinto')
        owners={w:c for c,l in enumerate(LABELS) for w in neighbors[l]}
        require(len(owners)==sum(map(len,neighbors.values())) and not set(owners)&set(LABELS),'Vecinos solapados/contienen centros')
        require(all(len(v)>=6 for v in neighbors.values()),'Clase con menos de seis vecinos')
        require(set(expected.split_seed)==set(range(51)) and not expected.duplicated(['split_seed','word']).any(),'Splits incompletos/duplicados')
        require(not full.word.duplicated().any() and set(full.word)==set(expected.word),'FULL distinto de unión de consultas')
        require(expected.true_class.eq(expected.word.map(owners)).all(),'Clases incompatibles')
        variable=expected.groupby('word').agg(nc=('true_class','nunique'),lo=('validation_similarity','min'),hi=('validation_similarity','max'))
        require(variable.nc.eq(1).all() and (variable.hi-variable.lo).abs().le(1e-12).all(),'Geometría variable entre particiones')
        observed=expected.drop(columns='split_seed').drop_duplicates().sort_values('word').reset_index(drop=True)
        pd.testing.assert_frame_equal(observed,full[observed.columns].sort_values('word').reset_index(drop=True),check_dtype=False,check_exact=False,rtol=0,atol=1e-12)
        st=full.groupby('true_class').validation_similarity.agg(mean='mean',sd=lambda x:x.std(ddof=0))
        require(set(st.index)==set(range(8)) and st.sd.gt(1e-14).all(),'Estandarizador degenerado')
        z=(full.validation_similarity-full.true_class.map(st['mean']))/full.true_class.map(st.sd)
        require(np.allclose(z,full.similarity_wc_z,rtol=0,atol=1e-12),'Z no reproducida')
        ranges=full.groupby('true_class').similarity_wc_z.agg(['min','max'])
        lo=float(ranges['min'].max()); hi=float(ranges['max'].min())
        require(np.isfinite([lo,hi]).all() and hi>lo,'COMMON degenerado')
        edges=np.linspace(lo,hi,6)
        common=full.loc[full.similarity_wc_z.between(lo-1e-12,hi+1e-12)].copy()
        common['similarity_bin']=np.searchsorted(edges[1:-1],common.similarity_wc_z,side='right').clip(0,4)
        require(set(native_common.word)==set(common.word),'COMMON histórico diferente')
        native_edges=np.asarray(gate['edges'])
        require(np.allclose(native_edges,np.linspace(lo,hi,len(native_edges)),rtol=0,atol=1e-12),'Bordes históricos incompatibles')
        nb=np.searchsorted(native_edges[1:-1],native_common.similarity_wc_z,side='right').clip(0,len(native_edges)-2)
        require(np.array_equal(nb,native_common.similarity_bin),'Asignación histórica de bins no reproducida')
        cov=coverage(common); counts=expected.groupby('word').size()
        common['split_exposures']=common.word.map(counts)
        common['balanced_word_weight']=1/(40*common.set_index(['true_class','similarity_bin']).index.map(cov.stack()))
        weight_sum=common.balanced_word_weight.sum()
        # La superficie fija5 no existe si falta una celda: no renormalizar pesos.
        valid=bool(cov.ge(1).all().all())
        kish=float(1/common.balanced_word_weight.pow(2).sum()) if valid else None
        for c in range(8):
            f=full.loc[full.true_class.eq(c)]; q=common.loc[common.true_class.eq(c)]
            classes.append(dict(**base,true_class=c,label=LABELS[c],n_full=len(f),n_common=len(q),retention=len(q)/len(f),
                raw_similarity_sd=float(st.loc[c,'sd']),raw_similarity_min=f.validation_similarity.min(),raw_similarity_max=f.validation_similarity.max(),
                min_query_exposures=int(counts.loc[f.word].min()),max_query_exposures=int(counts.loc[f.word].max())))
            for b in range(5):
                cell=q.loc[q.similarity_bin.eq(b)]; vals=np.sort(cell.similarity_wc_z.unique())
                gaps=np.diff(np.r_[edges[b],vals,edges[b+1]])
                cells.append(dict(**base,true_class=c,label=LABELS[c],bin=b,n_words=len(cell),n_distinct_similarity=len(vals),
                    split_exposures=int(cell.split_exposures.sum()),max_single_word_weight=float(1/(40*len(cell))) if len(cell) else None,
                    max_gap_fraction=float(gaps.max()/(edges[b+1]-edges[b]))))
        qmap=common.set_index('word')
        for r in full.itertuples(index=False):
            inside=r.word in qmap.index
            words.append(dict(**base,word=r.word,true_class=int(r.true_class),label=LABELS[int(r.true_class)],
                validation_similarity=float(r.validation_similarity),similarity_wc_z=float(r.similarity_wc_z),
                in_common=inside,similarity_bin=int(qmap.loc[r.word,'similarity_bin']) if inside else None,
                query_split_exposures=int(counts.loc[r.word]),aggregate_weight=float(qmap.loc[r.word,'balanced_word_weight']) if inside and valid else None))
        audits=readj(folder/'split_audit.json') if dataset=='W2V' else None
        if dataset=='GloVe':
            split_receipt=pd.read_csv(folder/'split_structure.csv')
            require(len(split_receipt)==51 and set(split_receipt.split_seed)==set(range(51)) and split_receipt.complete.astype(str).str.lower().eq('true').all(),'Recibo GloVe A1 inválido')
        if audits is not None:
            require(len(audits)==51 and {a['split_seed'] for a in audits}==set(range(51)),'Auditoría TRAIN incompleta')
        for seed,s in expected.groupby('split_seed'):
            train=sorted(set(owners)-set(s.word)); tc=pd.Series([owners[w] for w in train]).value_counts().reindex(range(8),fill_value=0)
            qc=s.true_class.value_counts().reindex(range(8),fill_value=0)
            require(qc.ge(3).all() and tc.ge(3).all(),'Partición sin frecuencia mínima')
            if audits is not None:
                a=next(a for a in audits if a['split_seed']==seed)
                require(a['complete'] and not a['dropped_training_words'] and not a['dropped_validation_words'],'Descartes en partición W2V')
                require(digest(train)==a['train_words_sha'],'TRAIN lexical distinto')
                require(len(train)==a['n_training_after_filter'] and len(s)==a['n_validation_after_filter'],'Cardinalidad TRAIN/QUERY distinta')
            for c in range(8):
                splits.append(dict(**base,split_seed=int(seed),true_class=c,label=LABELS[c],n_train=int(tc.loc[c]),n_query=int(qc.loc[c]),
                    train_provenance='reconstructed_and_lexical_hash_verified' if audits is not None else 'complement_of_queries_supported_by_complete_receipt'))
        # Folds idénticos al procedimiento estático: palabra completa en un fold.
        units=full.sort_values('word').reset_index(drop=True)
        require(units.groupby('true_class').size().min()>=5,'Insuficiencia real para CV estratificada 5-fold')
        betas=np.asarray(protocol['betas'],float)
        require(len(betas)==98 and np.allclose(betas,.01+.005*np.arange(98),rtol=0,atol=1e-12),'Grilla beta incompatible')
        data=units.loc[units.index.repeat(len(betas)),['word','true_class','validation_similarity']].reset_index(drop=True)
        data['beta']=np.tile(betas,len(units)); data['n_items']=data.word.map(counts)*10
        check_design=(dataset,K) in [('GloVe',40),('W2V',40),('W2V',50)]
        ndesign=0
        for repeat in range(5):
            skf=StratifiedKFold(n_splits=5,shuffle=True,random_state=repeat)
            for fold,(ai,bi) in enumerate(skf.split(units.word,units.true_class)):
                train=units.iloc[ai]; test=units.iloc[bi]
                ts=train.groupby('true_class').validation_similarity.agg(n='size',unique='nunique',sd=lambda x:x.std(ddof=0))
                testn=test.groupby('true_class').size()
                support_ok=(set(ts.index)==set(range(8)) and set(testn.index)==set(range(8)) and ts.sd.gt(1e-14).all())
                require(support_ok,'CV degenerada')
                ctrain=coverage(common.loc[common.word.isin(train.word)]); ctest=coverage(common.loc[common.word.isin(test.word)])
                train_limits=train.groupby('true_class').validation_similarity.agg(['min','max'])
                outside=(test.validation_similarity.lt(test.true_class.map(train_limits['min'])-1e-12)|
                         test.validation_similarity.gt(test.true_class.map(train_limits['max'])+1e-12))
                cvrows.append(dict(**base,repeat=repeat,fold=fold,all_classes_train=True,all_classes_test=True,standardizer_valid=True,
                    min_train_words_class=int(ts.n.min()),min_test_words_class=int(testn.min()),min_unique_similarity_train_class=int(ts.unique.min()),
                    min_train_similarity_sd=float(ts.sd.min()),empty_train_common_cells=int(ctrain.eq(0).sum().sum()),
                    empty_test_common_cells=int(ctest.eq(0).sum().sum()),test_words_outside_train_similarity_range=int(outside.sum()),
                    n_test_words=len(test),cell_coverage_role='diagnostic_not_requirement_for_unbinned_model'))
                if check_design:
                    fi=dict(train=np.flatnonzero(data.word.isin(train.word)),test=np.flatnonzero(data.word.isin(test.word)))
                    for family in families:
                        if family['kind'] in ['constant','class_constant']:continue
                        X,Xt,w,info=design(dict(data=data,betas=betas),fi,family)
                        designrows.append(dict(**base,repeat=repeat,fold=fold,family=family['name'],n_parameters=family['p'],
                            active_parameters=X.shape[1],finite_train=bool(np.isfinite(X).all()),finite_test=bool(np.isfinite(Xt).all()),
                            weights_sum=float(w.sum()),max_abs_train_design=float(np.abs(X).max()),max_abs_test_design=float(np.abs(Xt).max())))
                        ndesign+=1;del X,Xt,w,info
        subset=[s for s in splits if s['equivalence_id']==ident]
        cr=[s for s in cvrows if s['equivalence_id']==ident]
        rows.append(dict(**base,n_archive_versions=len(items),representative_root=record['root'],n_full=len(full),n_common=len(common),
            retention=len(common)/len(full),common_lower=lo,common_upper=hi,common_width=hi-lo,
            min_words_cell=int(cov.min().min()),empty_cells=int(cov.eq(0).sum().sum()),singleton_cells=int(cov.eq(1).sum().sum()),
            five_bin_geometry_admissible=valid,full_min_words_class=int(full.groupby('true_class').size().min()),
            min_train_words_class=min(s['n_train'] for s in subset),min_query_words_class=min(s['n_query'] for s in subset),
            query_exposure_min=int(counts.min()),query_exposure_median=float(counts.median()),query_exposure_max=int(counts.max()),
            aggregate_max_word_weight=float(common.balanced_word_weight.max()) if valid else None,
            aggregate_weight_sum=float(weight_sum),weight_equivalent_word_count=kish,
            cv_folds_valid=len(cr),cv_min_train_words_class=min(s['min_train_words_class'] for s in cr),
            cv_min_test_words_class=min(s['min_test_words_class'] for s in cr),
            cv_max_empty_train_cells=max(s['empty_train_common_cells'] for s in cr),
            design_matrices_pairs_verified=ndesign))
        print(dataset,'K'+str(K),'FULL',len(full),'COMMON',len(common),'min',int(cov.min().min()),'singletons',int(cov.eq(1).sum().sum()),'CV',len(cr),'designs',ndesign,flush=True)
    tables=dict(resumen_geometrias=rows,cobertura_clase_bin=cells,palabras_y_exposicion=words,clases=classes,
        particiones=splits,folds_CV=cvrows,matrices_diseno=designrows,proveniencia=inventory,recibos_verificados=verified)
    for name,records in tables.items():pd.DataFrame(records).to_csv(out/(name+'.csv'),index=False)
    # Diferentes geometrías para una misma K no se fusionarían silenciosamente.
    summary_df=pd.DataFrame(rows)
    distinct=summary_df.groupby(['dataset','K']).size()
    require(distinct.eq(1).all(),'Hay geometrías inequivalentes para una misma K: revisar antes de interpretar')
    missing=[dict(dataset=d,K=k,status='NOT_PROVIDED') for d in ['GloVe','W2V'] for k in range(40,101,10) if not ((summary_df.dataset==d)&(summary_df.K==k)).any()]
    pd.DataFrame(missing).to_csv(out/'geometrias_ausentes.csv',index=False)
    status=dict(status='COMPLETE',outcomes_read=False,models_fitted=False,classification_rerun=False,
        export_files_verified=len(m['files']),historical_receipt_entries_verified=len(verified),
        archived_geometries=len(inventory),distinct_source_geometries=len(rows),folds_verified=len(cvrows),
        design_pairs_verified=len(designrows),source_module_sha256=sha(args.source),input_manifest_sha256=sha(root/'manifest.json'),
        first_admissible_in_audited_range={d:int(g.loc[g.five_bin_geometry_admissible,'K'].min()) for d,g in summary_df.groupby('dataset')},
        missing_geometries=missing,train_embedding_bytes_verified=False,nearest_neighbor_selection_recomputed=False,
        lower_K_claim=False,minimum_two_words_per_cell_imposed=False,
        covariance_or_independent_sample_size_claim=False,
        software=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__),
        seconds=time.perf_counter()-started)
    (out/'resultado.json').write_text(json.dumps(status,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
    print(json.dumps(status,indent=2,ensure_ascii=False),flush=True)

if __name__=='__main__':
    with threadpool_limits(limits=1):main()
