"""Reproduce sólo la auditoría geométrica; no ejecuta el experimento."""
from pathlib import Path, PurePosixPath
import os, subprocess, sys, tempfile, zipfile

base=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='e2_geo_') as temp:
    root=Path(temp).resolve()
    if os.name=='nt':root=Path('\\\\?\\'+str(root))
    with zipfile.ZipFile(base/'geometrias_originales.zip') as z:
        if z.testzip() is not None:raise RuntimeError('ZIP de entrada dañado')
        for info in z.infolist():
            rel=PurePosixPath(info.filename)
            if rel.is_absolute() or '..' in rel.parts or '\\' in info.filename or ':' in info.filename:
                raise RuntimeError('Ruta insegura: '+info.filename)
            target=root.joinpath(*rel.parts)
            if info.is_dir():target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(z.read(info))
    subprocess.run([sys.executable,str(base/'audit_geometry.py'),'--inputs',str(root),
        '--source',str(base/'reference'/'static_reference.py'),
        '--out',str(base/'resultados_reproducidos')],check=True)
print('Auditoría terminada. Consultar resultados_reproducidos/.')
